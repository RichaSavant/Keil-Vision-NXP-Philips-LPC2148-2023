//control the chasing LED pattern of eight LEDs using on/off switch 
//If the switch is on then the chasing in forward direction else backward direction.